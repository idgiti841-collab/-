// Main JavaScript for RTL E-Commerce

const sampleProducts = [
  { id: 1, title: 'لپ‌تاپ گیمینگ ایسوس', category: 'electronics', price: 68000000, icon: '💻', badge: 'ویژه', desc: 'پردازنده نسل جدید Core i7، حافظه 16GB و کارت گرافیک قدرتمند.' },
  { id: 2, title: 'گوشی موبایل هوشمند پرو', category: 'electronics', price: 45000000, icon: '📱', badge: 'جدید', desc: 'دوربین 108 مگاپیکسلی، نمایشگر 120Hz و باتری پرظرفیت.' },
  { id: 3, title: 'هدفون بی‌سیم نویز کنسلینگ', category: 'electronics', price: 9500000, icon: '🎧', badge: 'پرفروش', desc: 'کیفیت صدای شفاف و باتری با شارژدهی تا 30 ساعت مداوم.' },
  { id: 4, title: 'هودی زمستانه اسپرت', category: 'fashion', price: 1450000, icon: '🧥', badge: 'تخفیف', desc: 'جنس دورس داخل کرک درجه یک و دوخت مقاوم و شیک.' },
  { id: 5, title: 'کفش ورزشی سبک', category: 'fashion', price: 2800000, icon: '👟', badge: '', desc: 'طراحی ارگونومیک، ضد لغزش و مناسب دویدن و باشگاه.' },
  { id: 6, title: 'کتاب اثر مرکب', category: 'books', price: 210000, icon: '📚', badge: 'پیشنهادی', desc: 'راهنمای جامع موفقیت و گام‌های کوچک برای تغییرات بزرگ.' },
  { id: 7, title: 'کتاب هنر شفاف اندیشیدن', category: 'books', price: 260000, icon: '📖', badge: '', desc: 'شناخت خطاهای شناختی ذهن و تصمیم‌گیری‌های هوشمندانه‌تر.' },
  { id: 8, title: 'قهوه‌ساز اسپرسو اتوماتیک', category: 'home', price: 8200000, icon: '☕', badge: 'محبوب', desc: 'فشار 20 بار واقعی با قابلیت فوم‌ساز حرفه‌ای شیر.' },
  { id: 9, title: 'چراغ خواب و آباژور مدرن', category: 'home', price: 1150000, icon: '💡', badge: '', desc: 'نورپردازی آرامش‌بخش با قابلیت تغییر رنگ و تنظیم شدت روشنایی.' }
];

// Helper to format currency in Persian Toman
function formatPrice(num) {
  return num.toLocaleString('fa-IR') + ' تومان';
}

// Cart state management in LocalStorage
function getCart() {
  return JSON.parse(localStorage.getItem('shop_cart') || '[]');
}

function saveCart(cart) {
  localStorage.setItem('shop_cart', JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(productId) {
  const cart = getCart();
  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.qty += 1;
  } else {
    const prod = sampleProducts.find(p => p.id === productId);
    if (prod) {
      cart.push({ id: prod.id, title: prod.title, price: prod.price, icon: prod.icon, qty: 1 });
    }
  }
  saveCart(cart);
  alert('محصول به سبد خرید افزوده شد!');
}

function removeFromCart(productId) {
  let cart = getCart();
  cart = cart.filter(item => item.id !== productId);
  saveCart(cart);
  renderCartPage();
}

function updateQty(productId, delta) {
  const cart = getCart();
  const item = cart.find(i => i.id === productId);
  if (item) {
    item.qty += delta;
    if (item.qty <= 0) {
      removeFromCart(productId);
      return;
    }
    saveCart(cart);
    renderCartPage();
  }
}

function updateCartBadge() {
  const badge = document.getElementById('cart-badge');
  if (badge) {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    badge.textContent = count;
  }
}

// Render product card HTML
function renderProductCard(p) {
  return `
    <div class="product-card">
      ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ''}
      <div class="product-img">${p.icon}</div>
      <div class="product-info">
        <h3 class="product-title">${p.title}</h3>
        <p class="product-desc">${p.desc}</p>
        <div class="product-price-row">
          <span class="price">${formatPrice(p.price)}</span>
          <button class="btn-add-cart" onclick="addToCart(${p.id})">افزودن</button>
        </div>
        <a href="product-detail.html?id=${p.id}" style="margin-top:0.5rem; font-size:0.85rem; color:var(--accent-cyan); text-align:center;">مشاهده جزئیات</a>
      </div>
    </div>
  `;
}

// Render home featured products
function initHomePage() {
  const grid = document.getElementById('featured-grid');
  if (grid) {
    grid.innerHTML = sampleProducts.slice(0, 4).map(renderProductCard).join('');
  }
}

// Render product catalog
function initProductsPage() {
  const grid = document.getElementById('products-catalog');
  const searchInput = document.getElementById('search-input');
  const categoryLinks = document.querySelectorAll('.category-filter');

  let currentCategory = 'all';
  let searchQuery = '';

  function filterAndDisplay() {
    let filtered = sampleProducts;
    if (currentCategory !== 'all') {
      filtered = filtered.filter(p => p.category === currentCategory);
    }
    if (searchQuery.trim() !== '') {
      filtered = filtered.filter(p => p.title.includes(searchQuery) || p.desc.includes(searchQuery));
    }

    if (grid) {
      if (filtered.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align:center; padding: 2rem; color: var(--text-secondary);">هیچ محصولی با این مشخصات یافت نشد.</p>';
      } else {
        grid.innerHTML = filtered.map(renderProductCard).join('');
      }
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      filterAndDisplay();
    });
  }

  categoryLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      categoryLinks.forEach(l => l.classList.remove('active'));
      e.target.classList.add('active');
      currentCategory = e.target.getAttribute('data-category');
      filterAndDisplay();
    });
  });

  filterAndDisplay();
}

// Render Product Detail Page
function initDetailPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = parseInt(urlParams.get('id')) || 1;
  const product = sampleProducts.find(p => p.id === id) || sampleProducts[0];

  const container = document.getElementById('product-detail-view');
  if (container) {
    container.innerHTML = `
      <div class="detail-gallery">
        <div class="main-image">${product.icon}</div>
      </div>
      <div class="detail-info">
        <h1 style="font-size: 2rem; margin-bottom: 1rem;">${product.title}</h1>
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">${product.desc}</p>
        <div style="font-size: 1.8rem; font-weight: 800; color: var(--accent-cyan); margin-bottom: 2rem;">
          ${formatPrice(product.price)}
        </div>
        <button class="btn btn-primary" style="width: 100%; font-size: 1.1rem; margin-bottom: 2rem;" onclick="addToCart(${product.id})">
          افزودن به سبد خرید 🛒
        </button>
        <h3 style="margin-bottom: 0.5rem; color: var(--accent-cyan);">مشخصات فنی</h3>
        <ul class="specs-list">
          <li><span>دسته‌بندی:</span> <span>${product.category}</span></li>
          <li><span>گارانتی:</span> <span>۱۸ ماه ضمانت اصالت کالا</span></li>
          <li><span>ارسال:</span> <span>ارسال اکسپرس به سراسر کشور</span></li>
          <li><span>وضعیت انبار:</span> <span>موجود در انبار</span></li>
        </ul>
      </div>
    `;
  }
}

// Render Cart Page
function renderCartPage() {
  const listContainer = document.getElementById('cart-items-list');
  const totalElem = document.getElementById('cart-total-price');
  const countElem = document.getElementById('cart-total-items');

  if (!listContainer) return;
  const cart = getCart();

  if (cart.length === 0) {
    listContainer.innerHTML = '<p style="text-align:center; padding:2rem; color:var(--text-secondary);">سبد خرید شما خالی است.</p>';
    if (totalElem) totalElem.textContent = '۰ تومان';
    if (countElem) countElem.textContent = '۰';
    return;
  }

  listContainer.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div style="font-size:2.5rem;">${item.icon}</div>
      <div class="cart-item-info">
        <h4 style="margin-bottom: 0.25rem;">${item.title}</h4>
        <div style="color:var(--accent-cyan); font-weight:600;">${formatPrice(item.price)}</div>
      </div>
      <div class="qty-controls">
        <button class="qty-btn" onclick="updateQty(${item.id}, 1)">+</button>
        <span style="padding: 0 0.5rem;">${item.qty}</span>
        <button class="qty-btn" onclick="updateQty(${item.id}, -1)">-</button>
      </div>
      <button onclick="removeFromCart(${item.id})" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:1.2rem; margin-right:1rem;">✕</button>
    </div>
  `).join('');

  const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const count = cart.reduce((sum, item) => sum + item.qty, 0);

  if (totalElem) totalElem.textContent = formatPrice(total);
  if (countElem) countElem.textContent = count;
}

document.addEventListener('DOMContentLoaded', () => {
  updateCartBadge();
});